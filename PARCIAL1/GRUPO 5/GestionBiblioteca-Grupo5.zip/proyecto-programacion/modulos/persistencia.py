
"""
Módulo de Persistencia de Datos
Desarrollado por: LEE, HYO LIN

Funciones principales:
- inicializar_datos(): crea carpeta /datos y archivos JSON si no existen.
- leer(tabla): devuelve lista de registros de la tabla dada.
- escribir(tabla, registros): persiste toda la tabla.
- agregar_registro/eliminar_registro/actualizar_registro: helpers CRUD sencillos.
- generar_id(): genera IDs secuenciales con prefijo.
- validar_tabla(): valida claves mínimas.
- cargar_todo(): devuelve un dict con todas las tablas cargadas.
"""

from pathlib import Path
from typing import List, Dict, Any
import json
import os

# Compatibilidad con Python 3.7
try:
    from typing import Literal
except Exception:  # pragma: no cover
    from typing_extensions import Literal  # type: ignore

Tabla = Literal["libros", "usuarios", "prestamos"]

# Directorio de datos ANCLADO a la raíz del proyecto (un nivel arriba de /modulos)
DATOS_DIR = Path(__file__).resolve().parents[1] / "datos"

# Rutas de los archivos JSON
RUTAS: Dict[str, Path] = {
    "libros": DATOS_DIR / "libros.json",
    "usuarios": DATOS_DIR / "usuarios.json",
    "prestamos": DATOS_DIR / "prestamos.json",
}

# Claves mínimas esperadas por entidad (validación rápida)
CLAVES_ESPERADAS: Dict[str, set] = {
    "libros": {"titulo", "autor"},
    "usuarios": {"nombre"},
    "prestamos": {"usuario_dni"},
}

def _atomic_dump(path: Path, data: Any) -> None:
    """
    Primero escribe en un archivo temporal y, cuando termina bien,
    reemplaza el archivo final. Así nunca queda el JSON "cortado".
    Además, hace flush+fsync para mayor robustez (ante cortes de energía).
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.flush()
        os.fsync(f.fileno())
    tmp.replace(path)
    # fsync del directorio (POSIX) para asegurar la actualización del nombre
    if os.name == "posix":
        try:
            dir_fd = os.open(str(path.parent), os.O_RDONLY)
            try:
                os.fsync(dir_fd)
            finally:
                os.close(dir_fd)
        except OSError:
            pass

def inicializar_datos(seed: bool = True) -> bool:
    """
    Crea la carpeta /datos y los archivos JSON si no existen.
    También limpia .tmp huérfanos (o recupera si el final falta).
    """
    DATOS_DIR.mkdir(parents=True, exist_ok=True)

    # Limpiar/recuperar temporales si quedaron de una corrida interrumpida
    for ruta in RUTAS.values():
        tmp = ruta.with_suffix(ruta.suffix + ".tmp")
        if tmp.exists():
            if not ruta.exists():
                # Recuperar si el final no existe
                tmp.replace(ruta)
            else:
                # Si el final existe, descartamos el temporal
                try:
                    tmp.unlink()
                except OSError:
                    pass

    # Crear archivos si no existen
    for ruta in RUTAS.values():
        if not ruta.exists():
            _atomic_dump(ruta, [])  # listas vacías por defecto
    return True

def leer(tabla: Tabla) -> List[Dict[str, Any]]:
    """Lee y devuelve la lista de registros de una tabla JSON."""
    ruta = RUTAS[tabla]
    if not ruta.exists():
        inicializar_datos(seed=True)
    with ruta.open("r", encoding="utf-8") as f:
        try:
            datos = json.load(f)
        except json.JSONDecodeError:
            # Si está corrupto, lo reparamos a []
            datos = []
            _atomic_dump(ruta, datos)
    if not isinstance(datos, list):
        raise ValueError(f"El archivo {ruta.name} no contiene una lista JSON.")
    return datos

def escribir(tabla: Tabla, registros: List[Dict[str, Any]]) -> None:
    """Sobrescribe por completo la tabla con la lista de registros proporcionada."""
    if not isinstance(registros, list):
        raise TypeError("Registros debe ser una lista de diccionarios.")
    ruta = RUTAS[tabla]
    _atomic_dump(ruta, registros)

def agregar_registro(tabla: Tabla, registro: Dict[str, Any]) -> None:
    """Agrega un registro a la tabla indicada y guarda en disco."""
    registros = leer(tabla)
    registros.append(registro)
    escribir(tabla, registros)

def eliminar_registro(tabla: Tabla, predicado) -> int:
    """Elimina los registros que cumplan el predicado y devuelve cuántos borró."""
    registros = leer(tabla)
    nuevos = [r for r in registros if not predicado(r)]
    borrados = len(registros) - len(nuevos)
    if borrados:
        escribir(tabla, nuevos)
    return borrados

def actualizar_registro(tabla: Tabla, predicado, patch: Dict[str, Any]) -> int:
    """
    Actualiza los registros que cumplan un predicado.
    Devuelve cuántos se modificaron.
    Ej.: predicado = lambda r: r.get("id") == "LIB001"
    """
    registros = leer(tabla)
    count = 0
    for r in registros:
        if predicado(r):
            r.update(patch)
            count += 1
    if count:
        escribir(tabla, registros)
    return count

def generar_id(prefijo: str, existentes: List[Dict[str, Any]], campo: str, ancho: int = 3) -> str:
    """
    Genera IDs secuenciales del tipo 'LIB001', 'PREST007', etc.
    - prefijo: 'LIB', 'PREST', ...
    - campo: nombre del campo con el ID ('id' o 'codigo')
    """
    mayor = 0
    for r in existentes:
        v = str(r.get(campo, ""))
        if v.startswith(prefijo):
            sufijo = v[len(prefijo):]
            if sufijo.isdigit():
                mayor = max(mayor, int(sufijo))
    return f"{prefijo}{str(mayor + 1).zfill(ancho)}"

def validar_tabla(tabla: Tabla, registros: List[Dict[str, Any]]) -> List[str]:
    """Valida presencia de claves mínimas. Devuelve lista de errores (vacía si OK)."""
    errores = []
    claves = CLAVES_ESPERADAS.get(tabla, set())
    for idx, r in enumerate(registros, start=1):
        faltantes = claves - set(r.keys())
        if faltantes:
            errores.append(f"{tabla}[{idx}]: faltan claves {sorted(faltantes)}")
    return errores

def cargar_todo() -> Dict[str, List[Dict[str, Any]]]:
    """Devuelve un dict con las tres tablas cargadas."""
    return {t: leer(t) for t in RUTAS.keys()}
