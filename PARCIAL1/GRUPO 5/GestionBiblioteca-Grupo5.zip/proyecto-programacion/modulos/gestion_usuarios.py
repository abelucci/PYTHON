"""
Módulo de Gestión de Usuarios
Desarrollado por: MILITELLO, LUCA SANTINO

Usa listas para almacenar información de usuarios
"""

from utilidades import limpiar_pantalla, pausar
from modulos.persistencia import leer, escribir, generar_id, agregar_registro

def mostrar_menu_usuarios():
    """Muestra el menú de gestión de usuarios"""
    limpiar_pantalla()
    print("="*40)
    print("      GESTIÓN DE USUARIOS")
    print("="*40)
    print("1. Registrar usuario")
    print("2. Buscar usuario")
    print("3. Listar usuarios")
    print("4. Eliminar usuario")
    print("5. Volver al menú principal")
    print("="*40)

def registrar_usuario():
    """Función para registrar un usuario usando el sistema de persistencia"""
    print("\n--- REGISTRAR USUARIO ---")
    
    # Validación de entrada
    while True:
        nombre = input("Nombre: ").strip()
        if nombre and nombre.replace(" ", "").isalpha():
            break
        print("ERROR: El nombre solo debe contener letras y no puede estar vacío.")
    
    while True:
        apellido = input("Apellido: ").strip()
        if apellido and apellido.replace(" ", "").isalpha():
            break
        print("ERROR: El apellido solo debe contener letras y no puede estar vacío.")
    
    while True:
        dni = input("DNI (solo dígitos): ").strip()
        if dni and dni.isdigit() and len(dni) >= 7:
            # Verificar que el DNI no esté duplicado
            usuarios_existentes = leer("usuarios")
            if any(u.get("dni") == dni for u in usuarios_existentes):
                print("ERROR: Ya existe un usuario con ese DNI.")
                continue
            break
        else:
            print("ERROR: El DNI debe tener al menos 7 dígitos.")
    
    # Obtener usuarios existentes para generar ID único
    usuarios_existentes = leer("usuarios")
    
    # Crear diccionario con ID único usando mejores prácticas
    usuario = {
        "id": generar_id("USR", usuarios_existentes, "id"),
        "nombre": nombre,
        "apellido": apellido,
        "dni": dni
    }
    
    # Usar función de persistencia para guardar
    agregar_registro("usuarios", usuario)
    print(f"\nUsuario '{nombre} {apellido}' registrado exitosamente!")
    print(f"ID asignado: {usuario['id']}")
    pausar()

def buscar_usuario():
    """Función para buscar usuarios por DNI o nombre"""
    limpiar_pantalla()
    print("--- BUSCAR USUARIO ---")
    
    print("Buscar por:")
    print("1. DNI")
    print("2. Nombre o Apellido")
    print("3. Volver")
    
    while True:
        opcion = input("\nSeleccione opción [1-3]: ").strip()
        if opcion in ['1', '2', '3']:
            break
        print("ERROR: Seleccione 1, 2 o 3")
    
    if opcion == '3':
        return
    
    # Obtener término de búsqueda
    if opcion == '1':
        while True:
            termino = input("Ingrese DNI: ").strip()
            if termino.isdigit() and len(termino) >= 7:
                break
            print("ERROR: El DNI debe contener solo números y tener al menos 7 dígitos.")
        campo = 'dni'
    else:
        while True:
            termino = input("Ingrese nombre o apellido: ").strip().lower()
            if termino and termino.replace(" ", "").isalpha():
                break
            print("ERROR: El nombre o apellido solo debe contener letras.")
        campo = 'nombre_apellido'
    
    if not termino:
        print("ERROR: Debe ingresar un término de búsqueda")
        pausar()
        return
    
    # Cargar usuarios y buscar
    usuarios = leer("usuarios")
    encontrados = []
    
    for usuario in usuarios:
        if campo == 'dni':
            if usuario.get('dni', '') == termino:
                encontrados.append(usuario)
        else:  # Búsqueda por nombre o apellido
            nombre = str(usuario.get('nombre', '')).lower()
            apellido = str(usuario.get('apellido', '')).lower()
            if termino in nombre or termino in apellido:
                encontrados.append(usuario)
    
    # Mostrar resultados
    print(f"\n--- RESULTADOS DE BÚSQUEDA ---")
    if not encontrados:
        print("No se encontraron usuarios que coincidan con la búsqueda.")
    else:
        print(f"Se encontraron {len(encontrados)} usuario(s):")
        print("-" * 60)
        for usuario in encontrados:
            id_usuario = usuario.get('id', 'N/A')
            print(f"ID: {id_usuario} - {usuario['apellido']}, {usuario['nombre']} - DNI: {usuario['dni']}")
    
    pausar()

def eliminar_usuario():
    """Función para eliminar un usuario del sistema"""
    limpiar_pantalla()
    print("--- ELIMINAR USUARIO ---")
    
    # Primero mostrar usuarios disponibles
    usuarios = leer("usuarios")
    if not usuarios:
        print("No hay usuarios registrados para eliminar.")
        pausar()
        return
    
    print("Usuarios disponibles:")
    print("-" * 60)
    for usuario in usuarios:
        id_usuario = usuario.get('id', 'N/A')
        print(f"ID: {id_usuario} - {usuario['apellido']}, {usuario['nombre']} - DNI: {usuario['dni']}")
    
    print("-" * 60)
    id_eliminar = input("Ingrese el ID del usuario a eliminar (o 'cancelar'): ").strip()
    
    if id_eliminar.lower() == 'cancelar':
        print("Operación cancelada.")
        pausar()
        return
    
    # Buscar el usuario para confirmar
    usuario_encontrado = None
    for usuario in usuarios:
        if usuario.get('id') == id_eliminar:
            usuario_encontrado = usuario
            break
    
    if not usuario_encontrado:
        print(f"ERROR: No se encontró un usuario con ID '{id_eliminar}'")
        pausar()
        return
    
    # Confirmación
    print(f"\n¿Está seguro de eliminar este usuario?")
    print(f"ID: {usuario_encontrado['id']}")
    print(f"Nombre: {usuario_encontrado['nombre']} {usuario_encontrado['apellido']}")
    print(f"DNI: {usuario_encontrado['dni']}")
    
    confirmacion = input("\nEscriba 'CONFIRMAR' para eliminar: ").strip()
    
    if confirmacion == 'CONFIRMAR':
        from modulos.persistencia import eliminar_registro
        eliminados = eliminar_registro("usuarios", lambda u: u.get('id') == id_eliminar)
        
        if eliminados > 0:
            print(f"\nUsuario '{usuario_encontrado['nombre']} {usuario_encontrado['apellido']}' eliminado exitosamente!")
        else:
            print("ERROR: No se pudo eliminar el usuario.")
    else:
        print("Eliminación cancelada.")
    
    pausar()

def listar_usuarios():
    """Función para listar usuarios usando el sistema de persistencia"""
    limpiar_pantalla()
    print("--- LISTA DE USUARIOS ---")
    
    # Cargar usuarios usando la función de persistencia
    usuarios = leer("usuarios")
    
    if not usuarios:
        print("No hay usuarios registrados.")
    else:
        for usuario in usuarios:
            id_usuario = usuario.get('id', 'N/A')
            print(f"ID: {id_usuario} - {usuario['apellido']}, {usuario['nombre']} - DNI: {usuario['dni']}")
    
    pausar()

def menu_usuarios():
    """Menú principal de gestión de usuarios"""
    while True:
        mostrar_menu_usuarios()
        opcion = input("Seleccione una opción [1-5]: ")
        
        if opcion == "1":
            registrar_usuario()
        elif opcion == "2":
            buscar_usuario()
        elif opcion == "3":
            listar_usuarios()
        elif opcion == "4":
            eliminar_usuario()
        elif opcion == "5":
            break
        else:
            print("Opción inválida")
            pausar()
