"""
MODULO DE GESTION DE PRESTAMOS

Desarrollado por: KIDYBA, LAUTARO AGUSTIN

USA LISTAS PARA ALMACENAR INFORMACION DE PRESTAMOS
"""

from utilidades import limpiar_pantalla, pausar
from modulos.persistencia import leer, escribir, generar_id, agregar_registro

def mostrar_menu_prestamos():
    """Muestra el menu de gestion de prestamos"""
    limpiar_pantalla()
    print("="*40)
    print("      SISTEMA DE PRÉSTAMOS") 
    print("="*40)
    print("1. Realizar préstamo") 
    print("2. Ver préstamos activos") 
    print("3. Buscar préstamo")
    print("4. Eliminar préstamo")
    print("5. Volver al menú principal")
    print("="*40)

def realizar_prestamo():
    """Funcion para realizar un prestamo usando el sistema de persistencia."""
    print("\n--- REALIZAR PRÉSTAMO ---")
    
    # Validacion de entrada
    while True:
        dni_usuario = input("DNI del usuario (solo digitos): ").strip()
        if dni_usuario.isdigit() and len(dni_usuario) >= 7:
            break
        print("ERROR: El DNI debe contener solo números y tener al menos 7 dígitos.")

    while True:
        titulo_libro = input("Titulo del libro: ").strip()
        if titulo_libro:
            break
        print("ERROR: El titulo del libro no puede estar vacio.")

    # Validacion de existencia de usuario antes de realizar prestamos
    usuarios_existentes = leer("usuarios")
    usuario_encontrado = False
    for usuario in usuarios_existentes:
        if usuario["dni"].strip() == dni_usuario:
            usuario_encontrado = True
            break

    if not usuario_encontrado:
        print(f"Préstamo no otorgado. No existe un usuario con DNI '{dni_usuario}' registrado en el sistema.")
        pausar()
        return

    # Validacion de que exista el libro
    libros_existentes = leer("libros")
    libro_encontrado = False
    for libro in libros_existentes:
        if libro["titulo"].strip().lower() == titulo_libro.lower():
            libro_encontrado = True
            break

    if not libro_encontrado:
        print(f"Prestamo no otorgado. El libro '{titulo_libro}' no está registrado en el sistema.")
        pausar()
        return

    
    # Obtener prestamos existentes para generar ID
    prestamos_existentes = leer("prestamos")

    for p in prestamos_existentes:
        if p["libro_titulo"].strip().lower() == titulo_libro.lower() and p["estado"].lower() == "activo":
            print(f"El libro '{titulo_libro}' ya se encuentra prestado, intente nuevamente.")
            pausar()
            return
    
    # Crear diccionario con los datos usando las mejores practicas
    prestamo = {
        "id": generar_id("PREST", prestamos_existentes, "id"),
        "usuario_dni": dni_usuario,
        "libro_titulo": titulo_libro,
        "estado": "activo"
    }
    
    # Usar la función de persistencia para guardar
    agregar_registro("prestamos", prestamo)
    
    print(f"\nPrestamo registrado exitosamente!")
    print(f"ID del prestamo: {prestamo['id']}")
    pausar()

def listar_prestamos():
    """Funcion para listar prestamos usando el sistema de persistencia."""
    limpiar_pantalla()
    print("--- LISTA DE PRÉSTAMOS ---")
    
    # Cargar prestamos usando la función de persistencia
    prestamos = leer("prestamos")
    
    if not prestamos:
        print("No hay prestamos registrados.")
    else:
        for prestamo in prestamos:
            print(f"ID: {prestamo['id']} - Usuario: {prestamo['usuario_dni']} - Libro: {prestamo['libro_titulo']} - Estado: {prestamo['estado']}")
    
    pausar()

def buscar_prestamo():
    """Función para buscar préstamos por DNI del usuario, título del libro o ID del préstamo"""
    limpiar_pantalla()
    print("--- BUSCAR PRÉSTAMO ---")
    
    print("Buscar por:")
    print("1. DNI del usuario")
    print("2. Título del libro")
    print("3. ID del préstamo")
    print("4. Volver")
    
    while True:
        opcion = input("\nSeleccione opción [1-4]: ").strip()
        if opcion in ['1', '2', '3', '4']:
            break
        print("ERROR: Seleccione 1, 2, 3 o 4")
    
    if opcion == '4':
        return
    
    # Obtener término de búsqueda
    if opcion == '1':
        termino = input("Ingrese DNI del usuario: ").strip()
        campo = 'usuario_dni'
        busqueda_exacta = True
    elif opcion == '2':
        termino = input("Ingrese título del libro (o parte): ").strip().lower()
        campo = 'libro_titulo'
        busqueda_exacta = False
    else:  # opcion == '3'
        termino = input("Ingrese ID del préstamo: ").strip()
        campo = 'id'
        busqueda_exacta = True
    
    if not termino:
        print("ERROR: Debe ingresar un término de búsqueda")
        pausar()
        return
    
    # Cargar préstamos y buscar
    prestamos = leer("prestamos")
    encontrados = []
    
    for prestamo in prestamos:
        valor_campo = str(prestamo.get(campo, ''))
        
        if busqueda_exacta:
            if valor_campo == termino:
                encontrados.append(prestamo)
        else:
            if termino in valor_campo.lower():
                encontrados.append(prestamo)
    
    # Mostrar resultados
    print(f"\n--- RESULTADOS DE BÚSQUEDA ---")
    if not encontrados:
        print("No se encontraron préstamos con ese criterio.")
    else:
        print(f"Se encontraron {len(encontrados)} préstamo(s):")
        for prestamo in encontrados:
            print(f"ID: {prestamo['id']} - Usuario: {prestamo['usuario_dni']} - Libro: {prestamo['libro_titulo']} - Estado: {prestamo['estado']}")
    
    pausar()

def eliminar_prestamo():
    """Función para eliminar un préstamo por su ID"""
    limpiar_pantalla()
    print("--- ELIMINAR PRÉSTAMO ---")
    
    # Cargar préstamos actuales
    prestamos = leer("prestamos")
    
    if not prestamos:
        print("No hay préstamos registrados.")
        pausar()
        return
    
    # Mostrar préstamos disponibles
    print("Préstamos disponibles:")
    for prestamo in prestamos:
        print(f"ID: {prestamo['id']} - Usuario: {prestamo['usuario_dni']} - Libro: {prestamo['libro_titulo']} - Estado: {prestamo['estado']}")
    
    # Solicitar ID del préstamo a eliminar
    print("\nIngrese el ID del préstamo a eliminar (o 'cancelar' para volver):")
    id_prestamo = input("ID: ").strip()
    
    if id_prestamo.lower() == 'cancelar':
        return
    
    # Buscar el préstamo
    prestamo_encontrado = None
    for prestamo in prestamos:
        if prestamo['id'] == id_prestamo:
            prestamo_encontrado = prestamo
            break
    
    if not prestamo_encontrado:
        print(f"ERROR: No se encontró un préstamo con ID '{id_prestamo}'")
        pausar()
        return
    
    # Mostrar información del préstamo y confirmar eliminación
    print(f"\n¿Está seguro de eliminar este préstamo?")
    print(f"ID: {prestamo_encontrado['id']}")
    print(f"Usuario DNI: {prestamo_encontrado['usuario_dni']}")
    print(f"Libro: {prestamo_encontrado['libro_titulo']}")
    print(f"Estado: {prestamo_encontrado['estado']}")
    
    confirmacion = input("\nEscriba 'CONFIRMAR' para eliminar: ").strip()
    
    if confirmacion == 'CONFIRMAR':
        # Usar la función de persistencia para eliminar
        from modulos.persistencia import eliminar_registro
        eliminados = eliminar_registro("prestamos", lambda p: p['id'] == id_prestamo)
        
        if eliminados > 0:
            print(f"\nPréstamo '{prestamo_encontrado['id']}' eliminado exitosamente!")
        else:
            print("ERROR: No se pudo eliminar el préstamo")
    else:
        print("Eliminación cancelada.")
    
    pausar()

def menu_prestamos():
    """Menu principal de gestion de prestamos usando el sistema de persistencia."""
    # Ya no necesitamos cargar_prestamos() porque leer() lo hace automáticamente
    
    while True:
        mostrar_menu_prestamos()
        opcion = input("Seleccione una opcion [1-5]: ")
        
        if opcion == "1":
            realizar_prestamo()
        elif opcion == "2":
            listar_prestamos()
        elif opcion == "3":
            buscar_prestamo()
        elif opcion == "4":
            eliminar_prestamo()
        elif opcion == "5":
            print("Volviendo al menú principal...")
            break
        else:
            print("Opcion invalida. Por favor, seleccione un numero entre el 1 y el 5.")
            pausar()
