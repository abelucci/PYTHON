"""
Módulo de Gestión de Libros
Desarrollado por: IGLESIAS, MARTIN DAMIAN

Usa listas para almacenar información de libros
"""

from utilidades import limpiar_pantalla, pausar
from modulos.persistencia import leer, escribir, generar_id, agregar_registro



def mostrar_menu_libros():
    """Muestra el menú de gestión de libros"""
    limpiar_pantalla()
    print("="*40)
    print("      GESTIÓN DE LIBROS")
    print("="*40)
    print("1. Agregar libro")
    print("2. Buscar libro")
    print("3. Listar todos los libros")
    print("4. Eliminar libro")
    print("5. Volver al menú principal")
    print("="*40)

def agregar_libro():
    """Función para agregar un libro usando el sistema de persistencia"""
    print("\n--- AGREGAR LIBRO ---")
    
    # Validación de entrada
    while True:
        titulo = input("Título: ").strip()
        if titulo:
            break
        print("ERROR: El título no puede estar vacío.")
    
    while True:
        autor = input("Autor: ").strip()
        if autor:
            break
        print("ERROR: El autor no puede estar vacío.")
    
    # Obtener libros existentes para generar ID único
    libros_existentes = leer("libros")

    #validar libros existentes para evitar duplicados
    for l in libros_existentes:
        if l["titulo"].strip().lower() == titulo.lower() and l["autor"].strip().lower() == autor.lower():
            print(f"\n El libro '{titulo}' del autor {autor} ya se encuentra registrado.")
            pausar()
            return
    
    # Crear diccionario con ID único usando mejores prácticas
    libro = {
        "id": generar_id("LIB", libros_existentes, "id"),
        "titulo": titulo,
        "autor": autor
    }
    
    # Usar función de persistencia para guardar
    agregar_registro("libros", libro)
    print(f"\nLibro '{titulo}' agregado exitosamente!")
    print(f"ID asignado: {libro['id']}")
    pausar()

def buscar_libro():
    """Función para buscar libros por título o autor"""
    limpiar_pantalla()
    print("--- BUSCAR LIBRO ---")
    
    print("Buscar por:")
    print("1. Título")
    print("2. Autor") 
    print("3. Volver")
    
    while True:
        opcion = input("\nSeleccione opción [1-3]: ").strip()
        if opcion in ['1', '2', '3']:
            break
        print("ERROR: Seleccione 1, 2 o 3")
    
    if opcion == '3':
        return
    
    # Obtener término de búsqueda
    if opcion == '1':
        termino = input("Ingrese título (o parte del título): ").strip().lower()
        campo = 'titulo'
    else:
        termino = input("Ingrese autor (o parte del autor): ").strip().lower()
        campo = 'autor'
    
    if not termino:
        print("ERROR: Debe ingresar un término de búsqueda")
        pausar()
        return
    
    # Cargar libros y buscar
    libros = leer("libros")
    encontrados = []
    
    for libro in libros:
        valor_campo = str(libro.get(campo, '')).lower()
        if termino in valor_campo:
            encontrados.append(libro)
    
    # Mostrar resultados
    print(f"\n--- RESULTADOS DE BÚSQUEDA ---")
    if not encontrados:
        print("No se encontraron libros que coincidan con la búsqueda.")
    else:
        print(f"Se encontraron {len(encontrados)} libro(s):")
        print("-" * 50)
        for libro in encontrados:
            print(f"ID: {libro['id']} - {libro['titulo']} - {libro['autor']}")
    
    pausar()

def eliminar_libro():
    """Función para eliminar un libro del sistema"""
    limpiar_pantalla()
    print("--- ELIMINAR LIBRO ---")
    
    # Primero mostrar libros disponibles
    libros = leer("libros")
    if not libros:
        print("No hay libros registrados para eliminar.")
        pausar()
        return
    
    print("Libros disponibles:")
    print("-" * 40)
    for libro in libros:
        print(f"ID: {libro['id']} - {libro['titulo']} - {libro['autor']}")
    
    print("-" * 40)
    id_eliminar = input("Ingrese el ID del libro a eliminar (o 'cancelar'): ").strip()
    
    if id_eliminar.lower() == 'cancelar':
        print("Operación cancelada.")
        pausar()
        return
    
    # Buscar el libro para confirmar
    libro_encontrado = None
    for libro in libros:
        if libro['id'] == id_eliminar:
            libro_encontrado = libro
            break
    
    if not libro_encontrado:
        print(f"ERROR: No se encontró un libro con ID '{id_eliminar}'")
        pausar()
        return
    
    # Confirmación
    print(f"\n¿Está seguro de eliminar este libro?")
    print(f"ID: {libro_encontrado['id']}")
    print(f"Título: {libro_encontrado['titulo']}")
    print(f"Autor: {libro_encontrado['autor']}")
    
    confirmacion = input("\nEscriba 'CONFIRMAR' para eliminar: ").strip()
    
    if confirmacion == 'CONFIRMAR':
        from modulos.persistencia import eliminar_registro
        eliminados = eliminar_registro("libros", lambda l: l['id'] == id_eliminar)
        
        if eliminados > 0:
            print(f"\nLibro '{libro_encontrado['titulo']}' eliminado exitosamente!")
        else:
            print("ERROR: No se pudo eliminar el libro.")
    else:
        print("Eliminación cancelada.")
    
    pausar()

def listar_libros():
    """Función para listar libros usando el sistema de persistencia"""
    limpiar_pantalla()
    print("--- LISTA DE LIBROS ---")
    
    # Cargar libros usando la función de persistencia
    libros = leer("libros")
    
    if not libros:
        print("No hay libros registrados.")
    else:
        for libro in libros:
            print(f"ID: {libro['id']} - {libro['titulo']} - {libro['autor']}")
    
    pausar()

def menu_libros():
    """Menú principal de gestión de libros"""
    while True:
        mostrar_menu_libros()
        opcion = input("Seleccione una opción [1-5]: ")
        
        if opcion == "1":
            agregar_libro()
        elif opcion == "2":
            buscar_libro()
        elif opcion == "3":
            listar_libros()
        elif opcion == "4":
            eliminar_libro()
        elif opcion == "5":
            break
        else:
            print("Opción inválida. Seleccione 1-5.")
            pausar()
