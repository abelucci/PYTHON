# SISTEMA DE GESTIÓN DE BIBLIOTECA

## Programación I - Proyecto Integrador

---

**UNIVERSIDAD ARGENTINA DE LA EMPRESA (UADE)**  
**Materia:** Programación I  
**Profesor:** ABEL ISRAEL LAIME HUANCA  
**Grupo:** 5

---

## INTEGRANTES DEL EQUIPO

| **Apellido y Nombre**       | **Rol**                               |
| --------------------------- | ------------------------------------- |
| **TASSONE, FACUNDO JAVIER** | Líder de Proyecto + Menú Principal    |
| **IGLESIAS, MARTIN DAMIAN** | Especialista en Persistencia de Datos |
| **MILITELLO, LUCA SANTINO** | Desarrollador Módulo Libros           |
| **LEE, HYO LIN**            | Desarrollador Módulo Usuarios         |
| **KIDYBA, LAUTARO AGUSTIN** | Desarrollador Módulo Préstamos        |

---

## ÍNDICE

1. [**Idea General del Proyecto**](#1-idea-general-del-proyecto)
2. [**Definición de Roles del Equipo**](#2-definición-de-roles-del-equipo)
3. [**Primer Boceto del Menú Principal**](#3-primer-boceto-del-menú-principal)
4. [**Ejemplo Inicial de Entrada/Salida por Consola**](#4-ejemplo-inicial-de-entradasalida-por-consola)
5. [**Estructura Técnica Inicial**](#5-estructura-técnica-inicial)
6. [**Actualizaciones del Proyecto**](#6-actualizaciones-del-proyecto)
7. [**Documentación Técnica del código**](#7-documentación-técnica-del-código)

---

## 1. IDEA GENERAL DEL PROYECTO

### **Nombre del Proyecto**

Sistema de Gestión de Biblioteca

### **Descripción del Proyecto**

Desarrollo de una aplicación de consola en Python que simule las operaciones básicas de una biblioteca. El sistema permitirá gestionar libros, usuarios y préstamos de manera sencilla e intuitiva.

### **Objetivo**

Crear un sistema funcional que permita:

- **Gestión de Libros**: Agregar, buscar, modificar y eliminar libros del catálogo
- **Gestión de Usuarios**: Registrar socios, mantener sus datos actualizados
- **Sistema de Préstamos**: Controlar préstamos y devoluciones de libros

### **Alcance**

- **Lenguaje**: Python
- **Interfaz**: Consola/Terminal
- **Persistencia**: Archivos JSON
- **Tipo de aplicación**: Standalone (sin base de datos)

---

## 2. DEFINICIÓN DE ROLES DEL EQUIPO

| **Integrante**          | **Rol**                                   | **Responsabilidades Principales**                                                                                   |
| ----------------------- | ----------------------------------------- | ------------------------------------------------------------------------------------------------------------------- |
| TASSONE, FACUNDO JAVIER | **Líder de Proyecto + Menú Principal**    | Coordinación del equipo, seguimiento del cronograma, implementación del menú principal y sistema de navegación      |
| IGLESIAS, MARTIN DAMIAN | **Especialista en Persistencia de Datos** | Diseño de la estructura de datos, implementación de la persistencia en archivos JSON, funciones de carga y guardado |
| MILITELLO, LUCA SANTINO | **Desarrollador Módulo Libros**           | CRUD completo de libros: agregar, buscar, listar, modificar y eliminar libros del sistema                           |
| LEE, HYO LIN            | **Desarrollador Módulo Usuarios**         | CRUD completo de usuarios: registro de socios, búsqueda, actualización y gestión de usuarios                        |
| KIDYBA, LAUTARO AGUSTIN | **Desarrollador Módulo Préstamos**        | Sistema de préstamos y devoluciones, validaciones de disponibilidad, control de fechas                              |

### **Coordinación entre Módulos**

- Cada desarrollador trabajará en su módulo específico
- El especialista en datos dará soporte a todos los módulos para la persistencia
- El líder coordinará la integración de todos los módulos

---

## 3. PRIMER BOCETO DEL MENÚ PRINCIPAL

### **Estructura Principal**

```
═══════════════════════════════════════
    SISTEMA DE GESTIÓN DE BIBLIOTECA
═══════════════════════════════════════

1. GESTIÓN DE LIBROS
   1.1. Agregar libro
   1.2. Buscar libro
   1.3. Listar todos los libros
   1.4. Modificar libro
   1.5. Eliminar libro
   1.6. Volver al menú principal

2. GESTIÓN DE USUARIOS
   2.1. Registrar nuevo usuario
   2.2. Buscar usuario
   2.3. Listar usuarios
   2.4. Modificar datos de usuario
   2.5. Eliminar usuario
   2.6. Volver al menú principal

3. SISTEMA DE PRÉSTAMOS
   3.1. Realizar préstamo
   3.2. Registrar devolución
   3.3. Ver préstamos activos
   3.4. Historial de préstamos
   3.5. Volver al menú principal

4. SALIR DEL SISTEMA

═══════════════════════════════════════
Seleccione una opción [1-4]: _
```

### **Flujo de Navegación**

```
INICIO → MENÚ PRINCIPAL → SUBMENÚ ESPECÍFICO → OPERACIÓN → CONFIRMACIÓN → MENÚ PRINCIPAL
```

### **Validaciones del Menú**

- Control de opciones válidas (1-4)
- Mensajes de error para entradas inválidas
- Confirmación antes de salir del sistema
- Navegación intuitiva entre módulos

---

## 4. EJEMPLO INICIAL DE ENTRADA/SALIDA POR CONSOLA

### **Ejemplo 1: Inicio del Sistema**

```
═══════════════════════════════════════
    SISTEMA DE GESTIÓN DE BIBLIOTECA
═══════════════════════════════════════
    Versión 1.0 - Grupo 5

Inicializando sistema...
Cargando datos de libros...
Cargando datos de usuarios...
Cargando datos de préstamos...

¡Sistema listo para usar!

Presione ENTER para continuar...
```

### **Ejemplo 2: Agregar un Libro (Módulo Libros)**

```
═══════════════════════════════════════
           AGREGAR NUEVO LIBRO
═══════════════════════════════════════

Ingrese los datos del libro:

Título: El Principito
Autor: Antoine de Saint-Exupéry
ISBN: 978-84-376-0494-7
Año de publicación: 1943
Género: Literatura infantil
Cantidad de ejemplares: 5

──────────────────────────────────────
CONFIRMACIÓN DE DATOS:
──────────────────────────────────────
Título: El Principito
Autor: Antoine de Saint-Exupéry
ISBN: 978-84-376-0494-7
Año: 1943
Género: Literatura infantil
Ejemplares: 5
──────────────────────────────────────

¿Los datos son correctos? (s/n): s

¡Libro agregado exitosamente!
ID asignado: LIB001

Presione ENTER para continuar...
```

### **Ejemplo 3: Realizar Préstamo (Módulo Préstamos)**

```
═══════════════════════════════════════
          REALIZAR PRÉSTAMO
═══════════════════════════════════════

Paso 1: Identificar al usuario
DNI del usuario: 12345678

Usuario encontrado:
  Nombre: Juan Pérez
  DNI: 12345678
  Estado: Activo

Paso 2: Seleccionar libro
ID del libro: LIB001

Libro encontrado:
  Título: El Principito
  Autor: Antoine de Saint-Exupéry
  Disponibles: 4 de 5

──────────────────────────────────────
RESUMEN DEL PRÉSTAMO:
──────────────────────────────────────
Usuario: Juan Pérez (DNI: 12345678)
Libro: El Principito
Fecha de préstamo: 22/09/2025
Fecha de devolución: 06/10/2025 (14 días)
──────────────────────────────────────

¿Confirma el préstamo? (s/n): s

¡Préstamo registrado exitosamente!
  Código: PREST001

El libro debe devolverse antes del: 06/10/2025

Presione ENTER para continuar...
```

### **Ejemplo 4: Manejo de Errores**

```
═══════════════════════════════════════
           BUSCAR LIBRO
═══════════════════════════════════════

Ingrese el título a buscar:
Error: El título no puede estar vacío.

Ingrese el título a buscar: python
Buscando libros con título "python"...

No se encontraron libros con ese título.

¿Desea realizar otra búsqueda? (s/n): n

Regresando al menú principal...
```

---

## 5. ESTRUCTURA TÉCNICA INICIAL

### **Archivos del Proyecto**

```
sistema-biblioteca/
├── main.py                    # Archivo principal con menú
├── modulos/
│   ├── gestion_libros.py     # Módulo de libros
│   ├── gestion_usuarios.py   # Módulo de usuarios
│   ├── gestion_prestamos.py  # Módulo de préstamos
│   └── persistencia.py       # Manejo de archivos JSON
├── datos/
│   ├── libros.json          # Datos de libros
│   ├── usuarios.json        # Datos de usuarios
│   └── prestamos.json       # Datos de préstamos
└── utilidades.py            # Funciones auxiliares
```

### **Tecnologías a Utilizar**

- **Python 3.x**: Lenguaje principal
- **JSON**: Formato de persistencia de datos
- **Librerías estándar**: `datetime`, `json`, `os`

### **Estructura de Datos (JSON)**

**Libro:**

```json
{
  "id": "LIB001",
  "titulo": "El Principito",
  "autor": "Antoine de Saint-Exupéry",
  "isbn": "978-84-376-0494-7",
  "año": 1943,
  "genero": "Literatura infantil",
  "total_ejemplares": 5,
  "ejemplares_disponibles": 4
}
```

**Usuario:**

```json
{
  "dni": "12345678",
  "nombre": "Juan",
  "apellido": "Pérez",
  "email": "juan.perez@email.com",
  "telefono": "1234567890",
  "fecha_registro": "22/09/2025",
  "activo": true
}
```

**Préstamo:**

```json
{
  "codigo": "PREST001",
  "usuario_dni": "12345678",
  "libro_id": "LIB001",
  "fecha_prestamo": "22/09/2025",
  "fecha_devolucion_esperada": "06/10/2025",
  "fecha_devolucion_real": null,
  "estado": "activo"
}
```

---

## 6. ACTUALIZACIONES DEL PROYECTO

### **ENTREGA 2 - Implementación (04/10/2025)**

#### **Código Implementado:**

- **main.py**: Sistema de menú principal funcional con navegación completa
- **Módulos operativos**: Cada módulo (libros, usuarios, préstamos) con funcionalidades básicas implementadas
- **Sistema de utilidades**: Funciones auxiliares para limpieza de pantalla y pausa

#### **Funcionalidades Activas:**

- **Gestión de Libros**: Agregar y listar libros con almacenamiento en memoria
- **Gestión de Usuarios**: Registrar y listar usuarios con datos básicos (nombre, apellido, DNI)
- **Sistema de Préstamos**: Crear y listar préstamos con ID automático y estado
- **Navegación completa**: Menús y submenús completamente funcionales

#### **Estructura de Datos Implementada:**

```python
# Listas en memoria para almacenamiento temporal
libros = []      # Diccionarios con id, titulo, autor
usuarios = []    # Diccionarios con nombre, apellido, dni
prestamos = []   # Diccionarios con id, usuario_dni, libro_titulo, estado
```

#### **Validaciones Implementadas:**

- Control de opciones válidas en todos los menús
- Manejo de errores de entrada del usuario
- Navegación segura entre módulos

#### **Estado Actual del Proyecto:**

- Menú funcionando con opciones básicas
- Estructura de directorios del proyecto
- Funciones principales esbozadas
- Uso de listas y cadenas (strings)

### **Próximos Pasos (Entrega 3):**

- Desarrollo de estructura de datos completa
- Implementar persistencia real con archivos JSON
- Agregar validaciones más robustas
- Funciones de búsqueda y modificación
- Integración completa entre módulos
- Sistema de préstamos con validación de disponibilidad

---

## 7. Documentación Técnica del código

### **7.1 Módulo de Persistencia (persistencia.py)**

Este es el núcleo del sistema de datos, proporcionando operaciones atómicas y seguras:

```python
def leer(tabla: Tabla) -> List[Dict[str, Any]]:
    """Lee y devuelve la lista de registros de una tabla JSON."""
    ruta = RUTAS[tabla]
    if not ruta.exists():
        return []
    try:
        with ruta.open("r", encoding="utf-8") as f:
            datos = json.load(f)
        return datos if isinstance(datos, list) else []
    except (json.JSONDecodeError, UnicodeDecodeError, OSError):
        return []
```

#### **Funciones Principales:**

- **`leer(tabla)`**: Carga datos desde archivos JSON de forma segura
- **`escribir(tabla, registros)`**: Guarda datos con escritura atómica
- **`agregar_registro(tabla, nuevo_registro)`**: Añade nuevos registros
- **`eliminar_registro(tabla, predicado)`**: Elimina registros por condición
- **`generar_id(prefijo, registros, campo_id)`**: Genera IDs únicos automáticamente

```python
def escribir(tabla: Tabla, registros: List[Dict[str, Any]]) -> None:
    """Sobrescribe por completo la tabla con la lista de registros proporcionada."""
    if not isinstance(registros, list):
        raise TypeError("Registros debe ser una lista de diccionarios.")
    ruta = RUTAS[tabla]
    _atomic_dump(ruta, registros)

def _atomic_dump(path: Path, data: Any) -> None:
    """
    Primero escribe en un archivo temporal y, cuando termina bien,
    reemplaza el archivo final. Así nunca queda el JSON "cortado".
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.flush()
        os.fsync(f.fileno())
    tmp.replace(path)
```

```python
def generar_id(prefijo: str, existentes: List[Dict[str, Any]], campo: str, ancho: int = 3) -> str:
    """
    Genera IDs secuenciales del tipo 'LIB001', 'PREST007', etc.
    - prefijo: 'LIB', 'PREST', ...
    - campo: nombre del campo con el ID ('id' o 'codigo')
    """
    mayor = 0
    for r in existentes:
        v = str(r.get(campo, ""))
        if v.startswith(prefijo):
            sufijo = v[len(prefijo):]
            if sufijo.isdigit():
                mayor = max(mayor, int(sufijo))
    return f"{prefijo}{str(mayor + 1).zfill(ancho)}"
```

### **7.2 Sistema de Menús Principales (main.py)**

El archivo principal coordina la navegación entre módulos:

```python
def main():
    """Función principal del sistema"""

    # crea /datos y los .json si faltan
    inicializar_datos(seed=True)

    # Mensaje de bienvenida
    print("Iniciando Sistema de Biblioteca...")
    print("¡Bienvenido!")
    pausar()

    # Bucle principal del menú
    while True:
        mostrar_menu_principal()

        try:
            opcion = input("Seleccione una opción [1-4]: ").strip()

            if opcion == "1":
                menu_libros()
            elif opcion == "2":
                menu_usuarios()
            elif opcion == "3":
                menu_prestamos()
            elif opcion == "4":
                print("\n¡Gracias por usar nuestro sistema!")
                print("Hasta luego.")
                break
            else:
                print("\nOpción inválida. Por favor ingrese 1, 2, 3 o 4.")
                pausar()

        except KeyboardInterrupt:
            print("\n\n¡Hasta luego!")
            break
        except Exception as e:
            print(f"\nError: {e}")
            pausar()
```

#### **Funcionalidades:**

- **Inicialización**: Carga datos al arranque con `inicializar_datos(seed=True)`
- **Navegación**: Menú principal con validación de opciones
- **Manejo de Errores**: Captura de interrupciones y excepciones
- **Integración**: Llama a los módulos especializados

```python
def mostrar_menu_principal():
    """Muestra el menú principal del sistema"""
    limpiar_pantalla()
    print("="*50)
    print("    SISTEMA DE GESTIÓN DE BIBLIOTECA")
    print("="*50)
    print("    Versión 1.0 - Grupo 5")
    print("    UADE - Programación I")
    print("="*50)
    print()
    print("1. GESTIÓN DE LIBROS")
    print("2. GESTIÓN DE USUARIOS")
    print("3. SISTEMA DE PRÉSTAMOS")
    print("4. SALIR DEL SISTEMA")
    print()
    print("="*50)
```

### **7.3 Módulo de Gestión de Libros (gestion_libros.py)**

Implementa todas las operaciones CRUD para el catálogo de libros:

```python
def agregar_libro():
    """Función para agregar un libro usando el sistema de persistencia"""
    print("\n--- AGREGAR LIBRO ---")

    # Validación de entrada
    while True:
        titulo = input("Título: ").strip()
        if titulo:
            break
        print("ERROR: El título no puede estar vacío.")

    while True:
        autor = input("Autor: ").strip()
        if autor:
            break
        print("ERROR: El autor no puede estar vacío.")

    # Obtener libros existentes para generar ID único
    libros_existentes = leer("libros")

    # Crear diccionario con ID único usando mejores prácticas
    libro = {
        "id": generar_id("LIB", libros_existentes, "id"),
        "titulo": titulo,
        "autor": autor
    }

    # Usar función de persistencia para guardar
    agregar_registro("libros", libro)
    print(f"\nLibro '{titulo}' agregado exitosamente!")
    print(f"ID asignado: {libro['id']}")
    pausar()
```

#### **Operaciones Implementadas:**

- **Agregar Libro**: Validación de campos y generación automática de ID
- **Buscar Libro**: Búsqueda por título o autor (parcial o completa)
- **Listar Libros**: Visualización completa del catálogo
- **Eliminar Libro**: Eliminación con confirmación segura

```python
def buscar_libro():
    """Función para buscar libros por título o autor"""
    limpiar_pantalla()
    print("--- BUSCAR LIBRO ---")

    print("Buscar por:")
    print("1. Título")
    print("2. Autor")
    print("3. Volver")

    while True:
        opcion = input("\nSeleccione opción [1-3]: ").strip()
        if opcion in ['1', '2', '3']:
            break
        print("ERROR: Seleccione 1, 2 o 3")

    if opcion == '3':
        return

    # Obtener término de búsqueda
    if opcion == '1':
        termino = input("Ingrese título (o parte del título): ").strip().lower()
        campo = 'titulo'
    else:
        termino = input("Ingrese autor (o parte del autor): ").strip().lower()
        campo = 'autor'

    if not termino:
        print("ERROR: Debe ingresar un término de búsqueda")
        pausar()
        return

    # Cargar libros y buscar
    libros = leer("libros")
    encontrados = []

    for libro in libros:
        valor_campo = str(libro.get(campo, '')).lower()
        if termino in valor_campo:
            encontrados.append(libro)

    # Mostrar resultados
    if not encontrados:
        print("No se encontraron libros con ese criterio.")
    else:
        print(f"Se encontraron {len(encontrados)} libro(s):")
        for libro in encontrados:
            print(f"ID: {libro['id']} - {libro['titulo']} por {libro['autor']}")
```

#### **Características:**

- **Validación de Entrada**: Verificación de campos obligatorios
- **Búsqueda Flexible**: Permite búsquedas parciales insensibles a mayúsculas
- **Confirmación Segura**: Requiere escribir 'CONFIRMAR' para eliminar

### **7.4 Módulo de Gestión de Usuarios (gestion_usuarios.py)**

Maneja el registro y administración de socios de la biblioteca:

```python
def registrar_usuario():
    """Función para registrar un usuario usando el sistema de persistencia"""
    print("\n--- REGISTRAR USUARIO ---")

    # Validación de entrada
    while True:
        nombre = input("Nombre: ").strip()
        if nombre:
            break
        print("ERROR: El nombre no puede estar vacío.")

    while True:
        apellido = input("Apellido: ").strip()
        if apellido:
            break
        print("ERROR: El apellido no puede estar vacío.")

    while True:
        dni = input("DNI (solo dígitos): ").strip()
        if dni and dni.isdigit() and len(dni) >= 7:
            # Verificar que el DNI no esté duplicado
            usuarios_existentes = leer("usuarios")
            if any(u.get("dni") == dni for u in usuarios_existentes):
                print("ERROR: Ya existe un usuario con ese DNI.")
                continue
            break
        else:
            print("ERROR: El DNI debe contener al menos 7 dígitos.")

    # Crear usuario con ID automático
    usuario = {
        "id": generar_id("USU", usuarios_existentes, "id"),
        "nombre": nombre,
        "apellido": apellido,
        "dni": dni
    }

    # Guardar usando persistencia
    agregar_registro("usuarios", usuario)
    print(f"\nUsuario '{nombre} {apellido}' registrado exitosamente!")
    print(f"ID asignado: {usuario['id']}")
    pausar()
```

#### **Funcionalidades:**

- **Registro de Usuario**: Captura de nombre, apellido y DNI
- **Buscar Usuario**: Por DNI exacto o nombre/apellido parcial
- **Listar Usuarios**: Visualización ordenada de todos los socios
- **Eliminar Usuario**: Con confirmación mediante 'CONFIRMAR'

```python
def buscar_usuario():
    """Función para buscar usuarios por DNI o nombre"""
    limpiar_pantalla()
    print("--- BUSCAR USUARIO ---")

    print("Buscar por:")
    print("1. DNI")
    print("2. Nombre o Apellido")
    print("3. Volver")

    while True:
        opcion = input("\nSeleccione opción [1-3]: ").strip()
        if opcion in ['1', '2', '3']:
            break
        print("ERROR: Seleccione 1, 2 o 3")

    if opcion == '3':
        return

    # Lógica de búsqueda por DNI exacto o nombre/apellido parcial
    usuarios = leer("usuarios")
    if opcion == '1':
        termino = input("Ingrese DNI: ").strip()
        encontrados = [u for u in usuarios if u.get('dni') == termino]
    else:
        termino = input("Ingrese nombre o apellido: ").strip().lower()
        encontrados = [u for u in usuarios
                      if termino in u.get('nombre', '').lower()
                      or termino in u.get('apellido', '').lower()]

    # Mostrar resultados
    if not encontrados:
        print("No se encontraron usuarios con ese criterio.")
    else:
        print(f"Se encontraron {len(encontrados)} usuario(s):")
        for usuario in encontrados:
            print(f"ID: {usuario['id']} - {usuario['apellido']}, {usuario['nombre']} - DNI: {usuario['dni']}")
```

#### **Validaciones Implementadas:**

- **DNI**: Verificación de al menos 7 dígitos numéricos únicos
- **Nombres**: Validación de campos no vacíos
- **Duplicados**: Prevención de DNIs repetidos

### **7.5 Módulo de Sistema de Préstamos (gestion_prestamos.py)**

Controla el flujo de préstamos de libros:

```python
def realizar_prestamo():
    """Funcion para realizar un prestamo usando el sistema de persistencia."""
    print("\n--- REALIZAR PRÉSTAMO ---")

    # Validacion de entrada
    while True:
        dni_usuario = input("DNI del usuario (solo digitos): ").strip()
        if dni_usuario and dni_usuario.isdigit():
            break
        elif dni_usuario:
            print("ERROR: El DNI debe contener solo digitos.")
        else:
            print("ERROR: El DNI del usuario debe contener 8 digitos.")

    while True:
        titulo_libro = input("Titulo del libro: ").strip()
        if titulo_libro:
            break
        print("ERROR: El titulo del libro no puede estar vacio.")

    # Obtener prestamos existentes para generar ID
    prestamos_existentes = leer("prestamos")

    # Crear diccionario con los datos
    prestamo = {
        "id": generar_id("PREST", prestamos_existentes, "id"),
        "usuario_dni": dni_usuario,
        "libro_titulo": titulo_libro,
        "estado": "activo"
    }

    # Usar la función de persistencia para guardar
    agregar_registro("prestamos", prestamo)

    print(f"\nPrestamo registrado exitosamente!")
    print(f"ID del prestamo: {prestamo['id']}")
    pausar()
```

#### **Operaciones:**

- **Realizar Préstamo**: Asocia usuario con libro y genera ID automático
- **Ver Préstamos Activos**: Lista todos los préstamos en curso
- **Buscar Préstamo**: Por DNI de usuario, título de libro o ID de préstamo
- **Eliminar Préstamo**: Para gestión de devoluciones

```python
def buscar_prestamo():
    """Función para buscar préstamos por DNI del usuario, título del libro o ID del préstamo"""
    limpiar_pantalla()
    print("--- BUSCAR PRÉSTAMO ---")

    print("Buscar por:")
    print("1. DNI del usuario")
    print("2. Título del libro")
    print("3. ID del préstamo")
    print("4. Volver")

    while True:
        opcion = input("\nSeleccione opción [1-4]: ").strip()
        if opcion in ['1', '2', '3', '4']:
            break
        print("ERROR: Seleccione 1, 2, 3 o 4")

    if opcion == '4':
        return

    # Lógica de búsqueda por diferentes criterios
    prestamos = leer("prestamos")

    if opcion == '1':
        termino = input("Ingrese DNI del usuario: ").strip()
        encontrados = [p for p in prestamos if p.get('usuario_dni') == termino]
    elif opcion == '2':
        termino = input("Ingrese título del libro: ").strip().lower()
        encontrados = [p for p in prestamos if termino in p.get('libro_titulo', '').lower()]
    else:
        termino = input("Ingrese ID del préstamo: ").strip()
        encontrados = [p for p in prestamos if p.get('id') == termino]

    # Mostrar resultados
    if not encontrados:
        print("No se encontraron préstamos con ese criterio.")
    else:
        print(f"Se encontraron {len(encontrados)} préstamo(s):")
        for prestamo in encontrados:
            print(f"ID: {prestamo['id']} - Usuario: {prestamo['usuario_dni']} - Libro: {prestamo['libro_titulo']} - Estado: {prestamo['estado']}")
```

#### **Estructura de Datos:**

```json
{
  "id": "PREST001",
  "usuario_dni": "12345678",
  "libro_titulo": "El Quijote",
  "estado": "activo"
}
```

### **7.6 Utilidades Compartidas (utilidades.py)**

Funciones auxiliares utilizadas por todos los módulos:

### **8 Validaciones adicionales implementadas**

**Gestión de libros**:

- Verificación de que no se ingresen datos vacíos.
- Verificación de libro existente para evitar duplicados.

**Gestión de préstamos**

- Dni solicitado de al menos 7 dígitos.
- Validación de existencia de usuario antes de realizar préstamo.
- Validación de libro existente antes de realizar el préstamo.
- Validación de préstamo existente para evitar reservar libros ya prestados.

**Gestión de usuarios**

- Validación que nombre y apellido solo reciba letras al momento de registrar un usuario.
- Dni solicitado de al menos 7 dígitos.
- Validación que nombre y apellido solo reciba letras al momento de buscar un usuario.

```python
"""
Utilidades del Sistema
Funciones auxiliares para el sistema de gestión de biblioteca
"""

import os

def limpiar_pantalla():
    """Limpia la pantalla de la consola"""
    os.system('cls' if os.name == 'nt' else 'clear')

def pausar():
    """Pausa la ejecución hasta que el usuario presione Enter"""
    input("\nPresione Enter para continuar...")

def mostrar_mensaje(mensaje, tipo="info"):
    """Muestra un mensaje formateado"""
    if tipo == "error":
        print(f"ERROR: {mensaje}")
    elif tipo == "exito":
        print(f"✓ {mensaje}")
    else:
        print(f"INFO: {mensaje}")
```

#### **Funciones:**

- **`limpiar_pantalla()`**: Limpia la consola de forma multiplataforma
- **`pausar()`**: Pausa la ejecución esperando input del usuario
- **`mostrar_mensaje()`**: Muestra mensajes formateados

```
═══════════════════════════════════════════════════
    SISTEMA DE GESTIÓN DE BIBLIOTECA
═══════════════════════════════════════════════════
    Versión 1.0 - Grupo 5
    UADE - Programación I
═══════════════════════════════════════════════════

1. GESTIÓN DE LIBROS
2. GESTIÓN DE USUARIOS
3. SISTEMA DE PRÉSTAMOS
4. SALIR DEL SISTEMA

═══════════════════════════════════════════════════
Seleccione una opción [1-4]: _
```
