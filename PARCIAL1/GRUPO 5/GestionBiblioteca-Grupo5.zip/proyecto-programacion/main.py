# Importar módulos del sistema
from modulos.gestion_libros import menu_libros
from modulos.gestion_usuarios import menu_usuarios  
from modulos.gestion_prestamos import menu_prestamos
from utilidades import limpiar_pantalla, pausar
from modulos.persistencia import inicializar_datos

def mostrar_menu_principal():
    """Muestra el menú principal del sistema"""
    limpiar_pantalla()
    print("="*50)
    print("    SISTEMA DE GESTIÓN DE BIBLIOTECA")
    print("="*50)
    print("    Versión 1.0 - Grupo 5")
    print("    UADE - Programación I")
    print("="*50)
    print()
    print("1. GESTIÓN DE LIBROS")
    print("2. GESTIÓN DE USUARIOS")  
    print("3. SISTEMA DE PRÉSTAMOS")
    print("4. SALIR DEL SISTEMA")
    print()
    print("="*50)


def main():
    """Función principal del sistema"""
    
    # crea /datos y los .json si faltan
    inicializar_datos(seed=True)   
    
    # Mensaje de bienvenida
    print("Iniciando Sistema de Biblioteca...")
    print("¡Bienvenido!")
    pausar()
    
    # Bucle principal del menú
    while True:
        mostrar_menu_principal()
        
        try:
            opcion = input("Seleccione una opción [1-4]: ").strip()
            
            if opcion == "1":
                menu_libros()
            elif opcion == "2": 
                menu_usuarios()
            elif opcion == "3":
                menu_prestamos()
            elif opcion == "4":
                print("\n¡Gracias por usar nuestro sistema!")
                print("Hasta luego.")
                break
            else:
                print("\nOpción inválida. Por favor ingrese 1, 2, 3 o 4.")
                pausar()
                
        except KeyboardInterrupt:
            print("\n\n¡Hasta luego!")
            break
        except Exception as e:
            print(f"\nError: {e}")
            pausar()


if __name__ == "__main__":
    main()
